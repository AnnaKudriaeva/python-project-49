import prompt


def greet():
    print('Welcome to the Brain Games!')


def welcome_user():
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    return name


def rule():
    print('What is the result of the expression?')


def your_answer():
    answer = prompt.string('Your answer: ')
    return answer


def game(is_number):
    name = welcome_user()
    rule()
    n = 0
    while n < 3:
        corr_ans = is_number()
        ans = your_answer()
        if str(ans) == str(corr_ans):
            print('Correct!')
            n += 1
        elif str(ans) != str(corr_ans):
            print(
                f"'{ans}'is wrong answer ;(. "
                f"Correct answer was '{corr_ans}'."
            )
            print(f"Let's try again, {name}!")
            break
    if n == 3:
        print(f'Congratulations, {name}!')
